# 🎮 Kumpulan Game - Hari Kartini

## 🚀 Deploy ke Vercel

### 1. Upload ke GitHub dulu
```bash
git init
git add .
git commit -m "Initial commit - Kartini Game Collection"
git remote add origin https://github.com/USERNAME/REPO.git
git push -u origin main
```

### 2. Import di Vercel
- Buka [vercel.com](https://vercel.com)
- New Project → Import from GitHub
- Pilih repo ini

### 3. Setup Leaderboard Database (Vercel KV)
- Di Vercel Dashboard → Storage → Create Database → KV
- Sambungkan ke project kamu
- Vercel otomatis set environment variables

### 4. Deploy!
Setelah KV terhubung, deploy ulang. Leaderboard akan berfungsi untuk semua pemain!

---

## 🕹️ Kontrol

| Platform | Kontrol |
|----------|---------|
| **HP/Tablet** | Virtual Joystick di kiri bawah, tombol aksi di kanan bawah |
| **PC/Laptop** | WASD, Arrow Keys, atau Numpad 8462 (atas/kiri/bawah/kanan) |

## 📁 Struktur
```
Index/          → File game utama
  joystick.js   → Universal joystick library
  leaderboard.js → Leaderboard (cloud + lokal fallback)
api/
  leaderboard.js → Vercel serverless API
vercel.json     → Konfigurasi Vercel
package.json    → Dependencies (@vercel/kv)
```
