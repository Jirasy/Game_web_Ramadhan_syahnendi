// ==================== VERCEL SERVERLESS API - LEADERBOARD ====================
// Vercel KV (Redis) based leaderboard untuk shared scores antar semua user
// Setup: tambah Vercel KV di dashboard Vercel, atau gunakan fallback JSON di /tmp

// Coba pakai @vercel/kv jika tersedia, fallback ke in-memory (hilang tiap cold start)
let kv;
try { kv = require('@vercel/kv'); } catch { kv = null; }

const IN_MEMORY = {};  // fallback kalau KV tidak ada

async function kvGet(key) {
  if (kv) {
    try { return await kv.get(key); } catch { return null; }
  }
  return IN_MEMORY[key] || null;
}
async function kvSet(key, value) {
  if (kv) {
    try { await kv.set(key, value); return; } catch {}
  }
  IN_MEMORY[key] = value;
}

const LB_KEY = 'kartini_leaderboard_v1';

module.exports = async function handler(req, res) {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    return res.status(200).end();
  }

  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Content-Type', 'application/json');

  // GET /api/leaderboard → ambil semua scores
  if (req.method === 'GET') {
    const data = await kvGet(LB_KEY) || {};
    return res.status(200).json({ ok: true, data });
  }

  // POST /api/leaderboard → simpan score
  if (req.method === 'POST') {
    let body = req.body;
    if (typeof body === 'string') {
      try { body = JSON.parse(body); } catch { return res.status(400).json({ ok: false, error: 'Invalid JSON' }); }
    }

    const { gameName, username, score } = body || {};
    if (!gameName || !username || score == null || isNaN(score)) {
      return res.status(400).json({ ok: false, error: 'Missing fields: gameName, username, score' });
    }

    // Sanitize
    const safeName = String(username).trim().slice(0, 20);
    const safeGame = String(gameName).trim().slice(0, 50);
    const safeScore = Math.max(0, Math.floor(Number(score)));

    // Load current data
    let data = await kvGet(LB_KEY) || {};
    if (!data[safeGame]) data[safeGame] = [];

    const entry = {
      username: safeName,
      score: safeScore,
      date: new Date().toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: '2-digit' }),
      ts: Date.now()
    };

    // Keep only best score per user
    const idx = data[safeGame].findIndex(e => e.username === safeName);
    if (idx >= 0) {
      if (safeScore > data[safeGame][idx].score) {
        data[safeGame][idx] = entry;
      } else {
        // Score not better, no update needed
        return res.status(200).json({ ok: true, updated: false, current: data[safeGame][idx].score });
      }
    } else {
      data[safeGame].push(entry);
    }

    // Sort and trim to top 100
    data[safeGame].sort((a, b) => b.score - a.score);
    data[safeGame] = data[safeGame].slice(0, 100);

    await kvSet(LB_KEY, data);
    return res.status(200).json({ ok: true, updated: true, rank: data[safeGame].findIndex(e => e.username === safeName) + 1 });
  }

  return res.status(405).json({ ok: false, error: 'Method not allowed' });
};
