const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let paddle, ball, bricks, keys;
let gameRunning = false;
let score = 0;
let moveDir = 0; // -1 left, 0 none, 1 right

const brickRowCount = 4;
const brickColumnCount = 7;
const brickPadding = 6;
const brickOffsetTop = 30;

function resizeCanvas() {
  const maxW = Math.min(window.innerWidth - 24, 560);
  canvas.width = maxW;
  canvas.height = Math.min(window.innerHeight * 0.55, 380);
}
window.addEventListener("resize", () => { if (gameRunning) resizeCanvas(); });
resizeCanvas();

function getBrickWidth() {
  return (canvas.width - brickOffsetTop * 2 - brickPadding * (brickColumnCount - 1)) / brickColumnCount;
}

function startGame() {
  resizeCanvas();
  const paddleColor = document.getElementById("paddleColor").value;
  const ballColor = document.getElementById("ballColor").value;
  const bw = getBrickWidth();

  paddle = {
    x: canvas.width / 2 - 45,
    y: canvas.height - 22,
    width: 90,
    height: 10,
    speed: 7,
    vx: 0,
    color: paddleColor
  };

  ball = {
    x: canvas.width / 2,
    y: canvas.height - 40,
    radius: 8,
    dx: 4,
    dy: -4,
    color: ballColor
  };

  bricks = [];
  for (let c = 0; c < brickColumnCount; c++) {
    bricks[c] = [];
    for (let r = 0; r < brickRowCount; r++) {
      bricks[c][r] = { x: 0, y: 0, status: 1 };
    }
  }

  score = 0;
  keys = {};
  moveDir = 0;

  document.getElementById("menu").style.display = "none";
  canvas.style.display = "block";
  document.getElementById("touch-controls").style.display = "flex";
  gameRunning = true;
}

function restartBreakout() {
  document.getElementById("breakout-gameover").style.display = "none";
  document.getElementById("menu").style.display = "flex";
  canvas.style.display = "none";
  document.getElementById("touch-controls").style.display = "none";
}

// Keyboard
document.addEventListener("keydown", e => {
  keys[e.key] = true;
  if (e.key === "ArrowLeft") paddle && (paddle.vx = -paddle.speed);
  if (e.key === "ArrowRight") paddle && (paddle.vx = paddle.speed);
});
document.addEventListener("keyup", e => {
  keys[e.key] = false;
  if (e.key === "ArrowLeft" || e.key === "ArrowRight") paddle && (paddle.vx = 0);
});

// Touch button continuous move
function startMove(dir) {
  if (!gameRunning || !paddle) return;
  paddle.vx = dir === 'LEFT' ? -paddle.speed : paddle.speed;
}
function stopMove() {
  if (paddle) paddle.vx = 0;
}

// Swipe on canvas
let touchStartX = null;
canvas.addEventListener("touchstart", e => { touchStartX = e.touches[0].clientX; e.preventDefault(); }, { passive: false });
canvas.addEventListener("touchmove", e => {
  if (!touchStartX || !gameRunning || !paddle) return;
  const dx = e.touches[0].clientX - touchStartX;
  paddle.vx = dx > 0 ? paddle.speed : -paddle.speed;
  e.preventDefault();
}, { passive: false });
canvas.addEventListener("touchend", () => { paddle && (paddle.vx = 0); touchStartX = null; });

function drawPaddle() {
  ctx.fillStyle = paddle.color;
  ctx.beginPath();
  ctx.roundRect(paddle.x, paddle.y, paddle.width, paddle.height, 5);
  ctx.fill();
}

function drawBall() {
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
  ctx.fillStyle = ball.color;
  ctx.fill();
  ctx.closePath();
}

function drawBricks() {
  const bw = getBrickWidth();
  const bh = 18;
  const colors = ['#ff6b6b', '#ffd43b', '#69db7c', '#74c0fc'];
  for (let c = 0; c < brickColumnCount; c++) {
    for (let r = 0; r < brickRowCount; r++) {
      if (bricks[c][r].status === 1) {
        const brickX = c * (bw + brickPadding) + brickOffsetTop;
        const brickY = r * (bh + brickPadding) + brickOffsetTop;
        bricks[c][r].x = brickX;
        bricks[c][r].y = brickY;
        ctx.fillStyle = colors[r];
        ctx.beginPath();
        ctx.roundRect(brickX, brickY, bw, bh, 4);
        ctx.fill();
      }
    }
  }
}

function collisionDetection() {
  const bw = getBrickWidth();
  const bh = 18;
  for (let c = 0; c < brickColumnCount; c++) {
    for (let r = 0; r < brickRowCount; r++) {
      const b = bricks[c][r];
      if (b.status === 1 &&
        ball.x > b.x && ball.x < b.x + bw &&
        ball.y > b.y && ball.y < b.y + bh) {
        ball.dy = -ball.dy;
        b.status = 0;
        score++;
        // Win check
        if (score === brickRowCount * brickColumnCount) {
          showEndScreen('🎉', 'Menang!', 'Semua bata hancur!', score, true);
        }
      }
    }
  }
}

function update() {
  if (!gameRunning) return;
  paddle.x += paddle.vx;
  if (paddle.x <= 0) { paddle.x = 0; }
  if (paddle.x + paddle.width >= canvas.width) { paddle.x = canvas.width - paddle.width; }

  ball.x += ball.dx;
  ball.y += ball.dy;

  if (ball.x + ball.radius > canvas.width || ball.x - ball.radius < 0) ball.dx = -ball.dx;
  if (ball.y - ball.radius < 0) ball.dy = -ball.dy;

  // Paddle hit
  if (ball.y + ball.radius >= paddle.y &&
    ball.y - ball.radius <= paddle.y + paddle.height &&
    ball.x > paddle.x && ball.x < paddle.x + paddle.width) {
    ball.dy = -Math.abs(ball.dy);
    // Adjust angle based on hit position
    const hitPos = (ball.x - (paddle.x + paddle.width / 2)) / (paddle.width / 2);
    ball.dx = hitPos * 5;
  }

  if (ball.y + ball.radius > canvas.height) {
    showEndScreen('💀', 'Game Over!', 'Bola jatuh!', score, false);
  }

  collisionDetection();
}

function showEndScreen(emoji, title, msg, finalScore, won) {
  gameRunning = false;
  window.LB && window.LB.save('Breakout', finalScore);
  document.getElementById('go-emoji').textContent = emoji;
  document.getElementById('go-title').textContent = title;
  document.getElementById('go-msg').textContent = msg;
  document.getElementById('go-score-txt').textContent = 'Skor: ' + finalScore;
  document.getElementById('breakout-gameover').style.display = 'flex';
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  if (!gameRunning) return;
  drawBricks();
  drawPaddle();
  drawBall();
  ctx.fillStyle = "white";
  ctx.font = "bold 16px Segoe UI";
  ctx.fillText("Skor: " + score, 10, 20);
}

function gameLoop() {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}
gameLoop();
