 // Default configuration
    const defaultConfig = {
      game_title: "GALAXY DEFENDERS",
      start_button_text: "MULAI GAME",
      primary_color: "#06b6d4",
      secondary_color: "#1e293b",
      text_color: "#ffffff",
      accent_color: "#22d3ee",
      font_family: "Orbitron"
    };

    let config = { ...defaultConfig };

    // Initialize Element SDK
    if (window.elementSdk) {
      window.elementSdk.init({
        defaultConfig,
        onConfigChange: async (newConfig) => {
          config = { ...defaultConfig, ...newConfig };
          
          const titleEl = document.getElementById("gameTitle");
          if (titleEl) {
            titleEl.textContent = config.game_title || defaultConfig.game_title;
            titleEl.style.color = config.primary_color || defaultConfig.primary_color;
          }
          
          const startBtn = document.getElementById("startBtn");
          if (startBtn) {
            startBtn.textContent = config.start_button_text || defaultConfig.start_button_text;
          }
          
          document.body.style.fontFamily = `${config.font_family || defaultConfig.font_family}, Rajdhani, sans-serif`;
        },
        mapToCapabilities: (cfg) => ({
          recolorables: [
            {
              get: () => cfg.primary_color || defaultConfig.primary_color,
              set: (v) => { cfg.primary_color = v; window.elementSdk.setConfig({ primary_color: v }); }
            },
            {
              get: () => cfg.secondary_color || defaultConfig.secondary_color,
              set: (v) => { cfg.secondary_color = v; window.elementSdk.setConfig({ secondary_color: v }); }
            },
            {
              get: () => cfg.text_color || defaultConfig.text_color,
              set: (v) => { cfg.text_color = v; window.elementSdk.setConfig({ text_color: v }); }
            },
            {
              get: () => cfg.accent_color || defaultConfig.accent_color,
              set: (v) => { cfg.accent_color = v; window.elementSdk.setConfig({ accent_color: v }); }
            }
          ],
          borderables: [],
          fontEditable: {
            get: () => cfg.font_family || defaultConfig.font_family,
            set: (v) => { cfg.font_family = v; window.elementSdk.setConfig({ font_family: v }); }
          },
          fontSizeable: undefined
        }),
        mapToEditPanelValues: (cfg) => new Map([
          ["game_title", cfg.game_title || defaultConfig.game_title],
          ["start_button_text", cfg.start_button_text || defaultConfig.start_button_text]
        ])
      });
    }

    // Game Configuration
    const LEVELS = {
      easy: { enemySpeed: 0.5, bulletSpeed: 4, enemyBulletSpeed: 2, fireRate: 800, enemyFireRate: 2500, maxWaves: 5 },
      medium: { enemySpeed: 0.8, bulletSpeed: 5, enemyBulletSpeed: 3, fireRate: 600, enemyFireRate: 1800, maxWaves: 7 },
      hard: { enemySpeed: 1.2, bulletSpeed: 6, enemyBulletSpeed: 4, fireRate: 400, enemyFireRate: 1200, maxWaves: 10 }
    };

    // Game State
    let gameState = {
      level: "easy",
      shipColor: "#00ffff",
      bulletColor: "#ff0000",
      score: 0,
      lives: 3,
      wave: 1,
      isPlaying: false,
      isPaused: false,
      player: null,
      enemies: [],
      playerBullets: [],
      enemyBullets: [],
      particles: [],
      stars: [],
      enemyDirection: 1,
      lastFireTime: 0,
      lastEnemyFireTime: 0,
      keys: { left: false, right: false, fire: false }
    };

    // DOM Elements
    const menuScreen = document.getElementById("menuScreen");
    const gameScreen = document.getElementById("gameScreen");
    const pauseScreen = document.getElementById("pauseScreen");
    const gameOverScreen = document.getElementById("gameOverScreen");
    const victoryScreen = document.getElementById("victoryScreen");
    const canvas = document.getElementById("gameCanvas");
    const ctx = canvas.getContext("2d");

    // Level Selection
    document.querySelectorAll(".level-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        document.querySelectorAll(".level-btn").forEach(b => {
          b.classList.remove("selected");
          b.style.borderColor = "transparent";
        });
        btn.classList.add("selected");
        btn.style.borderColor = btn.dataset.level === "easy" ? "#4ade80" : 
                                btn.dataset.level === "medium" ? "#facc15" : "#f87171";
        gameState.level = btn.dataset.level;
      });
    });

    // Ship Color Selection
    document.querySelectorAll(".color-option").forEach(opt => {
      opt.addEventListener("click", () => {
        document.querySelectorAll(".color-option").forEach(o => {
          o.classList.remove("selected");
          o.style.borderColor = "transparent";
        });
        opt.classList.add("selected");
        opt.style.borderColor = "white";
        gameState.shipColor = opt.dataset.color;
      });
    });

    // Bullet Color Selection
    document.querySelectorAll(".bullet-color-option").forEach(opt => {
      opt.addEventListener("click", () => {
        document.querySelectorAll(".bullet-color-option").forEach(o => {
          o.classList.remove("selected");
          o.style.borderColor = "transparent";
        });
        opt.classList.add("selected");
        opt.style.borderColor = "white";
        gameState.bulletColor = opt.dataset.bulletColor;
      });
    });

    // Start Game
    document.getElementById("startBtn").addEventListener("click", startGame);
    document.getElementById("pauseBtn").addEventListener("click", togglePause);
    document.getElementById("resumeBtn").addEventListener("click", togglePause);
    document.getElementById("restartBtn").addEventListener("click", () => { hidePause(); startGame(); });
    document.getElementById("menuBtn").addEventListener("click", backToMenu);
    document.getElementById("playAgainBtn").addEventListener("click", () => { hideGameOver(); startGame(); });
    document.getElementById("backToMenuBtn").addEventListener("click", backToMenu);
    document.getElementById("victoryPlayAgainBtn").addEventListener("click", () => { hideVictory(); startGame(); });
    document.getElementById("victoryMenuBtn").addEventListener("click", backToMenu);

    // Mobile Controls
    const leftBtn = document.getElementById("leftBtn");
    const rightBtn = document.getElementById("rightBtn");
    const fireBtn = document.getElementById("fireBtn");

    function setupMobileControl(btn, key) {
      btn.addEventListener("touchstart", (e) => { e.preventDefault(); gameState.keys[key] = true; });
      btn.addEventListener("touchend", (e) => { e.preventDefault(); gameState.keys[key] = false; });
      btn.addEventListener("mousedown", () => gameState.keys[key] = true);
      btn.addEventListener("mouseup", () => gameState.keys[key] = false);
      btn.addEventListener("mouseleave", () => gameState.keys[key] = false);
    }

    setupMobileControl(leftBtn, "left");
    setupMobileControl(rightBtn, "right");
    setupMobileControl(fireBtn, "fire");

    // Keyboard Controls
    document.addEventListener("keydown", (e) => {
      if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") gameState.keys.left = true;
      if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") gameState.keys.right = true;
      if (e.key === " " || e.key === "ArrowUp" || e.key === "w" || e.key === "W") {
        e.preventDefault();
        gameState.keys.fire = true;
      }
      if (e.key === "Escape" || e.key === "p" || e.key === "P") {
        if (gameState.isPlaying) togglePause();
      }
    });

    document.addEventListener("keyup", (e) => {
      if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") gameState.keys.left = false;
      if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") gameState.keys.right = false;
      if (e.key === " " || e.key === "ArrowUp" || e.key === "w" || e.key === "W") gameState.keys.fire = false;
    });

    function startGame() {
      const isMobile = window.innerWidth < 768;
      canvas.width = isMobile ? Math.min(400, window.innerWidth - 20) : 600;
      canvas.height = isMobile ? Math.min(500, window.innerHeight - 200) : 500;

      gameState = {
        ...gameState,
        score: 0,
        lives: 3,
        wave: 1,
        isPlaying: true,
        isPaused: false,
        player: { x: canvas.width / 2 - 20, y: canvas.height - 50, width: 40, height: 30, speed: 5 },
        enemies: [],
        playerBullets: [],
        enemyBullets: [],
        particles: [],
        stars: createStars(),
        enemyDirection: 1,
        lastFireTime: 0,
        lastEnemyFireTime: 0
      };

      spawnWave();
      updateHUD();

      menuScreen.classList.add("hidden");
      gameScreen.classList.remove("hidden");
      gameScreen.classList.add("flex");

      requestAnimationFrame(gameLoop);
    }

    function createStars() {
      const stars = [];
      for (let i = 0; i < 50; i++) {
        stars.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          size: Math.random() * 2 + 0.5,
          speed: Math.random() * 0.5 + 0.2,
          opacity: Math.random() * 0.5 + 0.5
        });
      }
      return stars;
    }

    function spawnWave() {
      gameState.enemies = [];
      const levelConfig = LEVELS[gameState.level];
      const rows = Math.min(3 + Math.floor(gameState.wave / 2), 5);
      const cols = Math.min(6 + gameState.wave, 10);
      const enemyWidth = 35;
      const enemyHeight = 25;
      const padding = 10;
      const startX = (canvas.width - (cols * (enemyWidth + padding))) / 2;

      for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
          const type = row === 0 ? 2 : (row < 2 ? 1 : 0);
          gameState.enemies.push({
            x: startX + col * (enemyWidth + padding),
            y: 50 + row * (enemyHeight + padding),
            width: enemyWidth,
            height: enemyHeight,
            type: type,
            frame: 0
          });
        }
      }
    }

    function togglePause() {
      if (!gameState.isPlaying) return;
      gameState.isPaused = !gameState.isPaused;
      pauseScreen.classList.toggle("hidden");
      pauseScreen.classList.toggle("flex");
      if (!gameState.isPaused) requestAnimationFrame(gameLoop);
    }

    function hidePause() {
      gameState.isPaused = false;
      pauseScreen.classList.add("hidden");
      pauseScreen.classList.remove("flex");
    }

    function showGameOver() {
      gameState.isPlaying = false;
      window.LB && window.LB.save('Space Shooter', gameState.score);
      document.getElementById("finalScore").textContent = gameState.score;
      document.getElementById("finalWave").textContent = gameState.wave;
      gameOverScreen.classList.remove("hidden");
      gameOverScreen.classList.add("flex");
    }

    function hideGameOver() {
      gameOverScreen.classList.add("hidden");
      gameOverScreen.classList.remove("flex");
    }

    function showVictory() {
      gameState.isPlaying = false;
      window.LB && window.LB.save('Space Shooter', gameState.score);
      document.getElementById("victoryScore").textContent = gameState.score;
      victoryScreen.classList.remove("hidden");
      victoryScreen.classList.add("flex");
    }

    function hideVictory() {
      victoryScreen.classList.add("hidden");
      victoryScreen.classList.remove("flex");
    }

    function backToMenu() {
      gameState.isPlaying = false;
      hidePause();
      hideGameOver();
      hideVictory();
      gameScreen.classList.add("hidden");
      gameScreen.classList.remove("flex");
      menuScreen.classList.remove("hidden");
    }

    function updateHUD() {
      document.getElementById("scoreDisplay").textContent = gameState.score;
      document.getElementById("waveDisplay").textContent = gameState.wave;
      const livesDisplay = document.getElementById("livesDisplay");
      livesDisplay.innerHTML = "";
      for (let i = 0; i < gameState.lives; i++) {
        const heart = document.createElement("span");
        heart.className = "text-xl md:text-2xl";
        heart.textContent = "❤️";
        livesDisplay.appendChild(heart);
      }
    }

    function createParticles(x, y, color, count = 10) {
      for (let i = 0; i < count; i++) {
        gameState.particles.push({
          x: x,
          y: y,
          vx: (Math.random() - 0.5) * 4,
          vy: (Math.random() - 0.5) * 4,
          size: Math.random() * 4 + 2,
          color: color,
          life: 1
        });
      }
    }

    function gameLoop(timestamp) {
      if (!gameState.isPlaying || gameState.isPaused) return;

      update(timestamp);
      render();
      requestAnimationFrame(gameLoop);
    }

    function update(timestamp) {
      const levelConfig = LEVELS[gameState.level];

      // Update stars
      gameState.stars.forEach(star => {
        star.y += star.speed;
        if (star.y > canvas.height) {
          star.y = 0;
          star.x = Math.random() * canvas.width;
        }
      });

      // Player movement
      if (gameState.keys.left) {
        gameState.player.x = Math.max(0, gameState.player.x - gameState.player.speed);
      }
      if (gameState.keys.right) {
        gameState.player.x = Math.min(canvas.width - gameState.player.width, gameState.player.x + gameState.player.speed);
      }

      // Player firing
      if (gameState.keys.fire && timestamp - gameState.lastFireTime > levelConfig.fireRate) {
        gameState.playerBullets.push({
          x: gameState.player.x + gameState.player.width / 2 - 2,
          y: gameState.player.y,
          width: 4,
          height: 12
        });
        gameState.lastFireTime = timestamp;
      }

      // Update player bullets
      gameState.playerBullets = gameState.playerBullets.filter(bullet => {
        bullet.y -= levelConfig.bulletSpeed;
        return bullet.y > -bullet.height;
      });

      // Enemy movement
      let moveDown = false;
      gameState.enemies.forEach(enemy => {
        enemy.x += levelConfig.enemySpeed * gameState.enemyDirection;
        if (enemy.x <= 0 || enemy.x + enemy.width >= canvas.width) {
          moveDown = true;
        }
      });

      if (moveDown) {
        gameState.enemyDirection *= -1;
        gameState.enemies.forEach(enemy => {
          enemy.y += 15;
          if (enemy.y + enemy.height > gameState.player.y) {
            showGameOver();
          }
        });
      }

      // Enemy firing
      if (timestamp - gameState.lastEnemyFireTime > levelConfig.enemyFireRate && gameState.enemies.length > 0) {
        const shooter = gameState.enemies[Math.floor(Math.random() * gameState.enemies.length)];
        gameState.enemyBullets.push({
          x: shooter.x + shooter.width / 2 - 2,
          y: shooter.y + shooter.height,
          width: 4,
          height: 10
        });
        gameState.lastEnemyFireTime = timestamp;
      }

      // Update enemy bullets
      gameState.enemyBullets = gameState.enemyBullets.filter(bullet => {
        bullet.y += levelConfig.enemyBulletSpeed;
        return bullet.y < canvas.height;
      });

      // Collision: player bullets vs enemies
      gameState.playerBullets = gameState.playerBullets.filter(bullet => {
        for (let i = gameState.enemies.length - 1; i >= 0; i--) {
          const enemy = gameState.enemies[i];
          if (checkCollision(bullet, enemy)) {
            createParticles(enemy.x + enemy.width / 2, enemy.y + enemy.height / 2, getEnemyColor(enemy.type), 15);
            gameState.score += (enemy.type + 1) * 10 * gameState.wave;
            gameState.enemies.splice(i, 1);
            updateHUD();
            return false;
          }
        }
        return true;
      });

      // Collision: enemy bullets vs player
      gameState.enemyBullets = gameState.enemyBullets.filter(bullet => {
        if (checkCollision(bullet, gameState.player)) {
          gameState.lives--;
          createParticles(gameState.player.x + gameState.player.width / 2, gameState.player.y + gameState.player.height / 2, gameState.shipColor, 20);
          updateHUD();
          if (gameState.lives <= 0) {
            showGameOver();
          }
          return false;
        }
        return true;
      });

      // Update particles
      gameState.particles = gameState.particles.filter(p => {
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 0.02;
        p.size *= 0.98;
        return p.life > 0;
      });

      // Check wave completion
      if (gameState.enemies.length === 0) {
        if (gameState.wave >= levelConfig.maxWaves) {
          showVictory();
        } else {
          gameState.wave++;
          spawnWave();
          updateHUD();
        }
      }
    }

    function checkCollision(a, b) {
      return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y;
    }

    function getEnemyColor(type) {
      const colors = ["#00ff88", "#ff6600", "#ff0066"];
      return colors[type] || colors[0];
    }

    function render() {
      // Clear canvas
      ctx.fillStyle = "#0a0a1a";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw stars
      gameState.stars.forEach(star => {
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 255, 255, ${star.opacity})`;
        ctx.fill();
      });

      // Draw player
      drawPlayer();

      // Draw enemies
      gameState.enemies.forEach(drawEnemy);

      // Draw player bullets
      ctx.fillStyle = gameState.bulletColor;
      ctx.shadowColor = gameState.bulletColor;
      ctx.shadowBlur = 10;
      gameState.playerBullets.forEach(bullet => {
        ctx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height);
      });
      ctx.shadowBlur = 0;

      // Draw enemy bullets
      ctx.fillStyle = "#ff3366";
      ctx.shadowColor = "#ff3366";
      ctx.shadowBlur = 8;
      gameState.enemyBullets.forEach(bullet => {
        ctx.beginPath();
        ctx.arc(bullet.x + bullet.width / 2, bullet.y + bullet.height / 2, 4, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.shadowBlur = 0;

      // Draw particles
      gameState.particles.forEach(p => {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.life;
        ctx.fill();
        ctx.globalAlpha = 1;
      });
    }

    function drawPlayer() {
      const p = gameState.player;
      ctx.save();
      ctx.shadowColor = gameState.shipColor;
      ctx.shadowBlur = 15;
      
      // Ship body
      ctx.fillStyle = gameState.shipColor;
      ctx.beginPath();
      ctx.moveTo(p.x + p.width / 2, p.y);
      ctx.lineTo(p.x + p.width, p.y + p.height);
      ctx.lineTo(p.x + p.width * 0.7, p.y + p.height * 0.7);
      ctx.lineTo(p.x + p.width / 2, p.y + p.height);
      ctx.lineTo(p.x + p.width * 0.3, p.y + p.height * 0.7);
      ctx.lineTo(p.x, p.y + p.height);
      ctx.closePath();
      ctx.fill();

      // Cockpit
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(p.x + p.width / 2, p.y + p.height * 0.4, 4, 0, Math.PI * 2);
      ctx.fill();

      // Engine glow
      ctx.fillStyle = "#ff6600";
      ctx.shadowColor = "#ff6600";
      ctx.beginPath();
      ctx.moveTo(p.x + p.width * 0.35, p.y + p.height);
      ctx.lineTo(p.x + p.width / 2, p.y + p.height + 8 + Math.random() * 4);
      ctx.lineTo(p.x + p.width * 0.65, p.y + p.height);
      ctx.closePath();
      ctx.fill();
      
      ctx.restore();
    }

    function drawEnemy(enemy) {
      ctx.save();
      const color = getEnemyColor(enemy.type);
      ctx.fillStyle = color;
      ctx.shadowColor = color;
      ctx.shadowBlur = 10;

      const e = enemy;
      
      if (enemy.type === 0) {
        // Basic enemy - squid shape
        ctx.beginPath();
        ctx.arc(e.x + e.width / 2, e.y + e.height * 0.4, e.width * 0.35, 0, Math.PI * 2);
        ctx.fill();
        for (let i = 0; i < 4; i++) {
          ctx.fillRect(e.x + i * e.width / 4 + 2, e.y + e.height * 0.6, 4, 10);
        }
      } else if (enemy.type === 1) {
        // Medium enemy - crab shape
        ctx.fillRect(e.x + e.width * 0.2, e.y, e.width * 0.6, e.height * 0.6);
        ctx.fillRect(e.x, e.y + e.height * 0.3, e.width, e.height * 0.4);
        ctx.fillStyle = "#000";
        ctx.fillRect(e.x + e.width * 0.25, e.y + e.height * 0.15, 5, 5);
        ctx.fillRect(e.x + e.width * 0.65, e.y + e.height * 0.15, 5, 5);
      } else {
        // Hard enemy - octopus shape
        ctx.beginPath();
        ctx.arc(e.x + e.width / 2, e.y + e.height * 0.35, e.width * 0.4, 0, Math.PI, true);
        ctx.fill();
        ctx.fillRect(e.x + e.width * 0.1, e.y + e.height * 0.35, e.width * 0.8, e.height * 0.4);
        ctx.fillStyle = "#fff";
        ctx.beginPath();
        ctx.arc(e.x + e.width * 0.35, e.y + e.height * 0.4, 4, 0, Math.PI * 2);
        ctx.arc(e.x + e.width * 0.65, e.y + e.height * 0.4, 4, 0, Math.PI * 2);
        ctx.fill();
      }
      
      ctx.restore();
    }

    // Handle resize
    window.addEventListener("resize", () => {
      if (gameState.isPlaying) {
        const isMobile = window.innerWidth < 768;
        canvas.width = isMobile ? Math.min(400, window.innerWidth - 20) : 600;
        canvas.height = isMobile ? Math.min(500, window.innerHeight - 200) : 500;
        gameState.stars = createStars();
      }
    });